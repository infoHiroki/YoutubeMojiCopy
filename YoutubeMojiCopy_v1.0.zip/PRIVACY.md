# Privacy Policy

This extension collects:
- YouTube transcript content for copying purposes
- User-selected prompt templates (stored locally)

We do not:
- Collect personal information
- Share any data with third parties
- Use data for purposes other than the extension's functionality

Contact: [Issues](https://github.com/infoHiroki/YouTubeMojiCopy/issues)
